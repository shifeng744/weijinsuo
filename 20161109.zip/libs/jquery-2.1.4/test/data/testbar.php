this.testBar = "bar";
jQuery("#ap").html("bar");
ok( true, "testbar.php executed");
